"use client";

import { useLanguage } from "@/components/providers/language-provider";

export function LanguageSwitch() {
  const { language, setLanguage, t } = useLanguage();
  return (
    <div className="language-switch" role="group" aria-label={t("Language")}>
      <button type="button" lang="en" aria-pressed={language === "en"} onClick={() => setLanguage("en")}>English</button>
      <span aria-hidden="true">|</span>
      <button type="button" lang="my" aria-pressed={language === "my"} onClick={() => setLanguage("my")}>မြန်မာ</button>
    </div>
  );
}
