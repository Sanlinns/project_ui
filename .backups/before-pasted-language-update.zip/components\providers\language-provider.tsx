"use client";

import { createContext, useContext, useState, type ReactNode } from "react";
import { LANGUAGE_COOKIE, messages, validateLanguage, type Language, type MessageKey } from "@/lib/i18n";

type LanguageContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: MessageKey) => string;
};
const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ initialLanguage, children }: { initialLanguage: Language; children: ReactNode }) {
  const [language, updateLanguage] = useState(initialLanguage);
  function setLanguage(value: Language) {
    const next = validateLanguage(value);
    document.cookie = `${LANGUAGE_COOKIE}=${next}; Path=/; Max-Age=31536000; SameSite=Lax${location.protocol === "https:" ? "; Secure" : ""}`;
    document.documentElement.lang = next;
    updateLanguage(next);
  }
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t: (key) => messages[language][key] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within the website LanguageProvider");
  return context;
}
