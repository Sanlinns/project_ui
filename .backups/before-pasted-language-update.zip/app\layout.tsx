import type { Metadata } from "next";
import { Geist, Geist_Mono, Noto_Sans_Myanmar } from "next/font/google";
import { ThemeProvider } from "@/components/providers/theme-provider";
import "./globals.css";
import { cookies } from "next/headers";
import { LanguageProvider } from "@/components/providers/language-provider";
import { LANGUAGE_COOKIE, validateLanguage } from "@/lib/i18n";

const myanmarFont = Noto_Sans_Myanmar({ variable: "--font-myanmar", subsets: ["myanmar"], weight: ["400", "500", "600", "700"], display: "swap" });
import {
  ToastProvider,
  Toaster,
} from "@/components/ui/toast"

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Binhlaig UI — Build beautiful interfaces, faster",
  description:
    "Accessible, responsive components and production-ready templates for modern web products.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/logo/ui_icon.png",
    shortcut: "/logo/ui_icon.png",
  },
};


export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const language = validateLanguage((await cookies()).get(LANGUAGE_COOKIE)?.value);
  return (
    <html lang={language} suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${myanmarFont.variable} antialiased`}

      >
        <ToastProvider>
          <ThemeProvider>
            <LanguageProvider initialLanguage={language}>{children}</LanguageProvider>
            <Toaster position="top-center" />
          </ThemeProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
