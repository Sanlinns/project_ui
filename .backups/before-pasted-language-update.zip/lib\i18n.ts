import en from "@/messages/en.json";
import my from "@/messages/my.json";

export type Language = "en" | "my";
export type MessageKey = keyof typeof en;
export const LANGUAGE_COOKIE = "binhlaig-language";
export const messages: Record<Language, Record<MessageKey, string>> = { en, my };
// Exact key parity is also checked in both directions by TypeScript.
const matchingKeys: Record<keyof typeof my, string> = en;
void matchingKeys;
export function validateLanguage(value: unknown): Language {
  return value === "my" ? "my" : "en";
}
